from flask import Flask, jsonify
from flask_cors import CORS
import mysql.connector
import os
import time

app = Flask(__name__)
CORS(app)

def get_db_connection():
    db_host = os.environ.get('DB_HOST', 'db-service')
    db_user = os.environ.get('DB_USER', 'root')
    db_password = os.environ.get('DB_PASSWORD', 'my-secret-pw')
    db_name = os.environ.get('DB_NAME', 'mydb')

    for i in range(5):
        try:
            conn = mysql.connector.connect(
                host=db_host,
                user=db_user,
                password=db_password,
                database=db_name
            )
            return conn
        except mysql.connector.Error:
            time.sleep(3)
    return None

@app.route('/api/data', methods=['GET'])
def get_data():
    conn = get_db_connection()
    if not conn:
        return jsonify({"status": "Error", "message": "Database connection failed"}), 500
    
    cursor = conn.cursor()
    cursor.execute("CREATE TABLE IF NOT EXISTS logs (id INT AUTO_INCREMENT PRIMARY KEY, message VARCHAR(255))")
    cursor.execute("INSERT INTO logs (message) VALUES ('DevOps Project Connection Successful!')")
    conn.commit()
    
    cursor.execute("SELECT message FROM logs ORDER BY id DESC LIMIT 1")
    result = cursor.fetchone()
    
    cursor.close()
    conn.close()
    
    return jsonify({
        "status": "Success",
        "database_message": result,
        "backend_status": "Python Flask API running smoothly!"
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
